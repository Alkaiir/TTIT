let buttonHamb = document.querySelector(".hamb-menu");
let headerNav = document.querySelector(".header-navigation");

buttonHamb.addEventListener("click", function () {
  if (headerNav.style.display === "none") {
    headerNav.style.display = "block";
  } else {
    headerNav.style.display = "none";
  }
});
